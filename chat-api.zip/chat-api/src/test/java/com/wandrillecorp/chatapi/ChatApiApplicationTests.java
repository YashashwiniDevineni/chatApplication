package com.wandrillecorp.chatapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ChatApiApplicationTests {

	@Test
	public void contextLoads() {
	}

}
