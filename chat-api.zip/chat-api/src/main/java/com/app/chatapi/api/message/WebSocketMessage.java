package com.app.chatapi.api.message;

public class WebSocketMessage {
}
